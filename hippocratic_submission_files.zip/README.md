# Hippocratic AI Take-Home: Bedtime Storyteller + LLM Judge

This repo implements a prompt-based bedtime story generator for ages **5–10** with an **LLM judge** that scores and improves the story via a short revision loop.

## How it works
1. **Spec builder** converts the user request into a compact story plan (characters, setting, arc, tone).
2. **Storyteller v1** writes an initial story from the spec.
3. **LLM Judge** evaluates the story using a rubric (age-appropriateness, coherence, creativity, engagement, clarity, ending) and returns **JSON** feedback.
4. **Revision** rewrites the story using the judge’s concrete instructions (1–2 iterations max).

Model is fixed to `gpt-3.5-turbo` per assignment requirements.

## Run locally

### 1) Install
```bash
pip install -r requirements.txt
```

### 2) Set your API key (do not commit it)
macOS/Linux:
```bash
export OPENAI_API_KEY="YOUR_KEY"
python main.py
```

Windows PowerShell:
```powershell
$env:OPENAI_API_KEY="YOUR_KEY"
python main.py
```

## (Optional) Run without an API key
If you want reviewers to run without calling OpenAI, set `USE_MOCK=true` and implement the small mock in `call_model` (see notes inside `main.py`).  
*(Leaving real calls enabled is fine for submission; just never include a key.)*

## Submission (GitHub)
1. Create a new GitHub repo (public or private, whichever they requested).
2. Copy these files into the repo root:
   - `main.py`
   - `diagram.md`
   - `requirements.txt`
   - `.env.example`
   - `README.md`
3. **Do not** commit `.env` or any secrets.
4. Push, then share the repository URL.

## Security
- API keys are read only from `OPENAI_API_KEY` in your environment.
- Never paste keys into code, notebooks, or GitHub.
