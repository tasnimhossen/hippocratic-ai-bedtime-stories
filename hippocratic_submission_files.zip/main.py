import os
from typing import Dict, List, Tuple
import json

"""
Before submitting the assignment, describe here in a few sentences what you would have built next if you spent 2 more hours on this project:

If I had 2 more hours, I would:
1. Add interactive storytelling where users can provide feedback and request changes mid-story
2. Implement story categorization (adventure, fairy tale, educational, etc.) with specialized prompts for each
3. Add a memory system to track story elements and ensure consistency across revisions
4. Create a more sophisticated evaluation rubric with weighted scores for different aspects
5. Add support for multi-chapter stories with story arcs across chapters
6. Implement A/B testing to compare different prompting strategies
"""

def call_model(prompt: str, max_tokens=3000, temperature=0.1) -> str:
    """Call OpenAI API with given prompt."""
    from openai import OpenAI
    client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
    resp = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": prompt}],
        max_tokens=max_tokens,
        temperature=temperature,
    )
    return resp.choices[0].message.content


class StorytellerAgent:
    """Agent responsible for generating age-appropriate stories."""

    def __init__(self):
        self.system_context = """You are an expert children's storyteller specializing in stories for ages 5-10.
Your stories are:
- Age-appropriate with simple vocabulary and concepts
- Engaging with clear character development
- Educational with positive moral lessons
- Imaginative and creative
- Safe and wholesome (no violence, scary content, or inappropriate themes)
- Structured with a clear beginning, middle, and end (story arc)
"""

    def generate_story(self, user_request: str, feedback: str = None, iteration: int = 1) -> str:
        """Generate a story based on user request and optional judge feedback."""

        if iteration == 1:
            # First generation - create initial story
            prompt = f"""{self.system_context}

Story Request: {user_request}

Please write an engaging bedtime story based on this request. Follow this structure:

1. BEGINNING: Introduce the main character(s) and setting in a captivating way
2. MIDDLE: Present a challenge or adventure that teaches a valuable lesson
3. END: Resolve the story with a satisfying conclusion and moral

The story should be:
- 400-600 words long
- Written at a 2nd-3rd grade reading level
- Include dialogue to make characters come alive
- Have descriptive language that sparks imagination
- End on a warm, comforting note perfect for bedtime

Write the story now:"""

        else:
            # Subsequent iterations - improve based on feedback
            prompt = f"""{self.system_context}

Original Story Request: {user_request}

JUDGE FEEDBACK:
{feedback}

Please revise the story addressing all the feedback points while maintaining the core story elements.
Make specific improvements to enhance:
- Age-appropriateness
- Engagement and pacing
- Character development
- Educational value
- Story structure

Write the improved story now:"""

        return call_model(prompt, max_tokens=1200, temperature=0.7)


class JudgeAgent:
    """Agent responsible for evaluating story quality and providing feedback."""

    def __init__(self):
        self.evaluation_criteria = {
            "age_appropriateness": "Content, vocabulary, and themes suitable for ages 5-10",
            "engagement": "Story captures attention with interesting plot and characters",
            "story_structure": "Clear beginning, middle, end with proper story arc",
            "educational_value": "Positive lessons or moral teachings",
            "language_quality": "Descriptive, imaginative language at appropriate reading level",
            "safety": "No scary, violent, or inappropriate content"
        }

    def evaluate_story(self, story: str, user_request: str) -> Dict:
        """Evaluate story quality and provide structured feedback."""

        criteria_list = "\n".join([f"- {k}: {v}" for k, v in self.evaluation_criteria.items()])

        prompt = f"""You are an expert judge evaluating children's stories for ages 5-10.

ORIGINAL REQUEST: {user_request}

STORY TO EVALUATE:
{story}

Please evaluate this story on the following criteria (rate each 1-10):
{criteria_list}

Provide your evaluation in this EXACT JSON format:
{{
    "scores": {{
        "age_appropriateness": <score>,
        "engagement": <score>,
        "story_structure": <score>,
        "educational_value": <score>,
        "language_quality": <score>,
        "safety": <score>
    }},
    "overall_score": <average score>,
    "strengths": ["<strength 1>", "<strength 2>", "<strength 3>"],
    "weaknesses": ["<weakness 1>", "<weakness 2>"],
    "specific_feedback": "<detailed feedback for improvement>",
    "needs_revision": <true or false>
}}

Evaluation:"""

        response = call_model(prompt, max_tokens=800, temperature=0.3)

        try:
            # Extract JSON from response
            json_start = response.find('{')
            json_end = response.rfind('}') + 1
            json_str = response[json_start:json_end]
            evaluation = json.loads(json_str)
            return evaluation
        except (json.JSONDecodeError, ValueError) as e:
            # Fallback if JSON parsing fails
            print(f"Warning: Could not parse judge evaluation as JSON: {e}")
            return {
                "overall_score": 7.0,
                "needs_revision": False,
                "specific_feedback": "Story appears acceptable but evaluation format was unclear."
            }


class StoryOrchestrator:
    """Orchestrates the storytelling process with iterative refinement."""

    def __init__(self, max_iterations=2, quality_threshold=8.0):
        self.storyteller = StorytellerAgent()
        self.judge = JudgeAgent()
        self.max_iterations = max_iterations
        self.quality_threshold = quality_threshold

    def create_story(self, user_request: str, verbose=True) -> Tuple[str, List[Dict]]:
        """
        Create a story with iterative refinement based on judge feedback.

        Returns:
            Tuple of (final_story, evaluation_history)
        """
        current_story = None
        evaluation_history = []

        for iteration in range(1, self.max_iterations + 1):
            if verbose:
                print(f"\n{'='*60}")
                print(f"ITERATION {iteration}")
                print(f"{'='*60}")

            # Generate or refine story
            if iteration == 1:
                if verbose:
                    print("📝 Generating initial story...")
                current_story = self.storyteller.generate_story(user_request, iteration=iteration)
            else:
                if verbose:
                    print("📝 Refining story based on feedback...")
                feedback = evaluation_history[-1]['specific_feedback']
                current_story = self.storyteller.generate_story(
                    user_request,
                    feedback=feedback,
                    iteration=iteration
                )

            # Evaluate story
            if verbose:
                print("⚖️  Evaluating story quality...")
            evaluation = self.judge.evaluate_story(current_story, user_request)
            evaluation_history.append(evaluation)

            if verbose:
                self._print_evaluation(evaluation)

            # Check if quality threshold is met
            overall_score = evaluation.get('overall_score', 0)
            needs_revision = evaluation.get('needs_revision', True)

            if overall_score >= self.quality_threshold or not needs_revision:
                if verbose:
                    print(f"\n✅ Quality threshold met (score: {overall_score:.1f})!")
                break

            if iteration < self.max_iterations:
                if verbose:
                    print(f"\n🔄 Score {overall_score:.1f} below threshold {self.quality_threshold}. Refining...")

        return current_story, evaluation_history

    def _print_evaluation(self, evaluation: Dict):
        """Print evaluation results in a readable format."""
        print(f"\n📊 Evaluation Results:")
        print(f"   Overall Score: {evaluation.get('overall_score', 'N/A')}/10")

        if 'scores' in evaluation:
            print(f"\n   Detailed Scores:")
            for criterion, score in evaluation['scores'].items():
                print(f"   • {criterion.replace('_', ' ').title()}: {score}/10")

        if 'strengths' in evaluation and evaluation['strengths']:
            print(f"\n   ✨ Strengths:")
            for strength in evaluation['strengths']:
                print(f"   • {strength}")

        if 'weaknesses' in evaluation and evaluation['weaknesses']:
            print(f"\n   ⚠️  Areas for Improvement:")
            for weakness in evaluation['weaknesses']:
                print(f"   • {weakness}")


def main():
    """Main function to run the storytelling system."""
    print("🌙 Welcome to the Bedtime Story Generator! 🌙")
    print("=" * 60)
    print("I create wonderful stories for children ages 5-10.")
    print("=" * 60)

    # Get user input
    user_input = input("\nWhat kind of story would you like to hear? ")

    if not user_input.strip():
        print("No story request provided. Using example request.")
        user_input = "A story about a girl named Alice and her best friend Bob, who happens to be a cat."

    # Create orchestrator and generate story
    orchestrator = StoryOrchestrator(max_iterations=2, quality_threshold=8.0)

    try:
        final_story, evaluation_history = orchestrator.create_story(user_input, verbose=True)

        # Print final story
        print("\n" + "=" * 60)
        print("📖 FINAL STORY")
        print("=" * 60)
        print(f"\n{final_story}\n")
        print("=" * 60)

        # Print summary
        print(f"\n Summary:")
        print(f"   Iterations: {len(evaluation_history)}")
        print(f"   Final Score: {evaluation_history[-1].get('overall_score', 'N/A')}/10")

        if len(evaluation_history) > 1:
            first_score = evaluation_history[0].get('overall_score', 0)
            last_score = evaluation_history[-1].get('overall_score', 0)
            improvement = last_score - first_score
            print(f"   Improvement: +{improvement:.1f} points")

    except Exception as e:
        print(f"\n Error generating story: {e}")
        print("Please check your OpenAI API key is set correctly.")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()