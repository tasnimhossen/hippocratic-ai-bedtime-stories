# Block Diagram

## ASCII
```
User Request
   |
   v
[Spec Builder Prompt]
   |
   v
[Storyteller Prompt]  ---> Story v1
   |
   v
[LLM Judge Prompt]   ---> JSON rubric scores + rewrite instructions
   |
   v
[Revision Prompt]    ---> Story v2 (and optional v3)
   |
   v
Final Story + (optional) Judge Scores
```

## Mermaid
```mermaid
flowchart TD
  U[User] --> S[Spec Builder]
  S --> T1[Storyteller v1]
  T1 --> J[LLM Judge (rubric + edits)]
  J --> T2[Storyteller Revision]
  T2 --> O[Output Story]
  J -->|optional scores| O
```
